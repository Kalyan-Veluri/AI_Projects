import cv2
import numpy as np
import pandas as pd
import random

# problem 1
image = cv2.imread('image.png')
gray_color = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
gray_color = np.float32(gray_color)
dest = cv2.cornerHarris(gray_color, 2,5,0.07)
dest = cv2.dilate(dest, None)

temp_image = np.copy(image)
image[dest > 0.01 * dest.max()] = [0, 0, 255]
cv2.imshow('image with borders', image)
# if cv2.waitKey(0) & 0xff == 27:
# 	cv2.destroyAllWindows()

result = []
for i in range(dest.shape[0]):
	for j in range(dest.shape[1]):
		if dest[i][j] > 0.01 * dest.max():
			result.append([i, j])

haha1 = []
haha2 = []
count = 0
for i in range(len(result)):
	# temp = random.randint(1, 12)
	haha1.append(result[i][0])
	haha2.append(result[i][1])
	count += 1
data = pd.DataFrame()
data['X'] = haha1
data['Y'] = haha2

# kmeans
def kmeans(X, k):
	diff = 1
	cluster = np.zeros(X.shape[0])
	centroids = data.sample(n=k).values
	while diff:
		# for each observation
		for i, row in enumerate(X):
			mn_dist = float('inf')
			# dist of the point from all centroids
			for idx, centroid in enumerate(centroids):
				d = np.sqrt((centroid[0]-row[0])**2 + (centroid[1]-row[1])**2)
				# store closest centroid
				if mn_dist > d:
					mn_dist = d
					cluster[i] = idx
		new_centroids = pd.DataFrame(X).groupby(by=cluster).mean().values
		# if centroids are same then leave
		if np.count_nonzero(centroids-new_centroids) == 0:
			diff = 0
		else:
			centroids = new_centroids
	return centroids, cluster

result_image = []
# kmeans cluster
for k in range(3, 6):
	temp_image = np.copy(image)
	X = data.values
	centroids, cluster = kmeans(X, k)

	result_list = [[] for t in range(k)]
	for i in range(len(cluster)):
		if cluster[i] == 0:
			temp_image[X[i][0]][X[i][1]] = [0,0,255]
			result_list[0].append(list(X[i]))
		elif cluster[i] == 1:
			temp_image[X[i][0]][X[i][1]] = [0,255,0]
			result_list[1].append(list(X[i]))
		elif cluster[i] == 2:
			temp_image[X[i][0]][X[i][1]] = [255,0,0]
			result_list[2].append(list(X[i]))
		elif cluster[i] == 3:
			temp_image[X[i][0]][X[i][1]] = [0,255,255]
			result_list[3].append(list(X[i]))
		else:
			temp_image[X[i][0]][X[i][1]] = [255, 255, 0]
			result_list[4].append(list(X[i]))

	cv2.imshow('image with kmeans', temp_image)
	if cv2.waitKey(0) & 0xff == 27:
		cv2.destroyAllWindows()

	def start_end_point(temp_list):
		temp_x = []
		temp_y = []
		for i in range(len(temp_list)):
			temp_x.append(temp_list[i][1])
			temp_y.append(temp_list[i][0])

		staring = [min(temp_x), min(temp_y)]
		ending = [max(temp_x), max(temp_y)]
		return staring, ending

	points = []
	for i in range(len(result_list)):
		starting, ending = start_end_point(result_list[i])
		print(starting, ending)
		if i == 0:
			temp_image = cv2.rectangle(temp_image, starting, ending, [0,0,255], 2)
		elif i == 1:
			temp_image = cv2.rectangle(temp_image, starting, ending, [0,255,0], 2)
		elif i == 2:
			temp_image = cv2.rectangle(temp_image, starting, ending, [255,0,0], 2)
		elif i == 3:
			temp_image = cv2.rectangle(temp_image, starting, ending, [0,255,255], 2)
		else:
			temp_image = cv2.rectangle(temp_image, starting, ending, [255, 255, 0], 2)

	cv2.imshow('image with bound rectangle', temp_image)

	if cv2.waitKey(0) & 0xff == 27:
		cv2.destroyAllWindows()
