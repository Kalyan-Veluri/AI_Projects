import numpy as np
import cv2 as cv

# problem 1
filename = "sample.jpg"
img = cv.imread(filename, 0)
equ = cv.equalizeHist(img)
cv.imshow('Origin', img)
cv.imshow('Histogram Eqaulization', equ)
e_dark = equ + 40
cv.imshow("Extreme Dark", e_dark)
m_dark = equ + 10
cv.imshow("Medium Dark", e_dark)
e_light = equ - 20
cv.imshow("Extreme Light", e_light)
cv.waitKey(0)

# problem 2
img = cv.imread(filename)
img_yuv = cv.cvtColor(img,cv.COLOR_BGR2YUV)
img_yuv[:,:,0] = cv.equalizeHist(img_yuv[:,:,0])
img_yuv[:,0,:] = cv.equalizeHist(img_yuv[:,0,:])
img_yuv[0,:,:] = cv.equalizeHist(img_yuv[0,:,:])
hist_eq = cv.cvtColor(img_yuv, cv.COLOR_YUV2BGR)
cv.imshow("Origin", img)
cv.imshow("Color Histogram Eqaulization", hist_eq)
e_dark = hist_eq + 20
cv.imshow("Extreme Dark", e_dark)
m_dark = hist_eq + 10
cv.imshow("Medium Dark", m_dark)
e_light = hist_eq - 10
cv.imshow("Extreme Light", e_light)
cv.waitKey(0)

# problem 3
img = cv.imread(filename, 0)
grad_x = cv.Sobel(img, cv.CV_16S, 1, 0, ksize=3)
grad_y = cv.Sobel(img, cv.CV_16S, 0, 1, ksize=3)

cv.imshow("x gradient", grad_x)
cv.imshow("y gradient", grad_y)
mag = np.sqrt((grad_x**2) + (grad_y**2))
cv.imshow("magnitude gradient", mag)

mag[mag < 87] = 0
cv.imshow("Thredhold 87 gradient", mag)
cv.waitKey(0)