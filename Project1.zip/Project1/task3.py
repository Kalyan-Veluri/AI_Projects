import numpy as np
import matplotlib.pyplot as plt
import cv2
from PIL import Image

source = "image.jpg"

# load the input image and convert it to grayscale
image = cv2.imread(source)
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
cv2.imshow("Gray", gray)
cv2.waitKey(0)
# compute gradients along the x and y axis, respectively
gx = cv2.Sobel(gray, cv2.CV_64F, 1, 0)
gy = cv2.Sobel(gray, cv2.CV_64F, 0, 1)

cv2.imshow("x-gradient", gx)
cv2.waitKey(0)

cv2.imshow("y-gradient", gy)
cv2.waitKey(0)


magnitude = np.sqrt((gx**2) + (gy**2))
cv2.imshow("magnitude gradient", magnitude)
cv2.waitKey(0)

threshold = 100
magnitude[magnitude < 100] = 0
cv2.imshow("threshold magnitude gradient", magnitude)
cv2.waitKey(0)
