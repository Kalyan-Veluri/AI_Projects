import numpy as np
from PIL import Image
import cv2

source = "image.jpg"
target = "gray_output3.png"

# read file as pillow Image
img = Image.open(source)
# convert to grayscale
imgray = img.convert(mode='L')
# convert to numpy array
img_array = np.asarray(imgray)
cv2.imshow("origin", img_array)
cv2.waitKey(0)

# flatten image array and calculate histogram
histogram_array = np.bincount(img_array.flatten(), minlength=256)

# normalize
num_pixels = np.sum(histogram_array)

def haha(name, reso):
	# histogram-equalized
	other_array = histogram_array / num_pixels * reso

	# cumulative histogram
	cum_array = np.cumsum(other_array)

	# pixel mapping
	tranform_array = np.floor(255 * cum_array).astype(np.int8)

	# flatten image array as 1D array
	img_list = list(img_array.flatten())

	# transform pixel values to equalize
	eq_list = [tranform_array[p] for p in img_list]

	# reshape
	eq_array = np.reshape(np.asarray(eq_list), img_array.shape)

	cv2.imshow(name, eq_array)
	cv2.waitKey(0)

haha("normal", 1)
haha("extreme dark", 2)
haha("medium dark", 1.5)
haha("extreme light", 1/2)